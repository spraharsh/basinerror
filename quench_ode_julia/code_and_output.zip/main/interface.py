#!/home/praharsh/anaconda3/envs/changebranch3 python
import numpy as np
import julia
from diffeqpy import de
from numpy.core.numeric import Inf, inf
j = julia.Julia()




# def get_negative_grad(x, p, t):
#     return - 2*x

class potclass:
    def __init__(self):
        self.f_eval = 0
    def get_negative_grad(self, x, p, t):
        self.f_eval += 1
        return -2*x
def get_negative_grad(x, p, t):
    return -2*x


u0 = 0.5
pot = potclass()
tspan = (0, 1.0)
print(pot.get_negative_grad(1, 1, 1))
prob = de.ODEProblem(pot.get_negative_grad,u0, tspan)
de.init(prob, de.Tsit5())






# def initialize_ode(get_negative_grad, x0):
#     tspan = (0, float('inf'))
#     prob = de.ODEProblem(get_negative_grad,x0, tspan)
#     return de.init(prob, de.Tsit5())


# def one_iteration(integrator):
#     de.step_b(integrator)
#     return (integrator.t, integrator.u, de.get_du(integrator))


# u0 = np.array([1, 1])
# pot = potclass()
# integrator = initialize_ode(pot.get_negative_grad, u0)
# ans = one_iteration(integrator)
# print(ans)


# de.step_b(integrator)            # error9











